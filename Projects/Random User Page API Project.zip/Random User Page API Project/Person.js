class Person {
    static id = 0

    constructor(){
        this.id =++Person.id
        this.personName = {}
        this.personLocate = {}
        this.pokemon = {}
        this.friends = {}

   }
}